import axios from "axios";

// ! DUMMY API CALL FROM JSON PLACEHOLDER

const GetUserList = async () => {
  const result = await axios.get("https://jsonplaceholder.typicode.com/users");
  console.count("result called");
  return result.data;
};

export { GetUserList };
