import React, { useState } from "react";
import { Button } from "react-bootstrap";
import Navbar from "./Navbar";

const HeadAndTail = () => {
  const [selectedValue, setSelectedValue] = useState("");
  const [valueArr, setValueArr] = useState([]);
  const [error, setError] = useState("");

  const dropDownChangeHanlder = (e) => {
    setSelectedValue(e.target.value);
  };
  let checkArray = (v) =>
    valueArr[valueArr.length - 1]?.find((res) => {
      return res === v;
    });
  const submitClickHandler = (e) => {
    e.preventDefault();
    setError(null);
    if (selectedValue === "") {
      setError("Please Select Value from dropdown");
    } else {
      if (valueArr.length > 0) {
        if (checkArray(selectedValue)) {
          valueArr[valueArr.length - 1].push(selectedValue);
        }
      }
      if (!checkArray(selectedValue)) {
        setValueArr((prev) => [...prev, [selectedValue]]);
      }
      setSelectedValue("");
      setError(null);
    }
  };

  console.log("Array", valueArr);

  return (
    <React.Fragment>
      <div>
        <Navbar />
      </div>
      <div>
        <h4 className="text-success">Head And Tail</h4>
        <select
          onChange={(e) => dropDownChangeHanlder(e)}
          value={selectedValue}
        >
          <option value="">Select Value</option>
          <option value="H">H</option>
          <option value="T">T</option>
        </select>
        <br />
        {error && error}
        <div style={{ display: "flex", justifyContent: "space-evenly" }}>
          {valueArr.map((res, i, arr) => (
            <div>
              {arr[i].map((res, i) => (
                <div key={i}>{res}</div>
              ))}
            </div>
          ))}
        </div>
      </div>
      <Button className="mt-5" onClick={submitClickHandler}>
        Submit
      </Button>
    </React.Fragment>
  );
};

export default HeadAndTail;
