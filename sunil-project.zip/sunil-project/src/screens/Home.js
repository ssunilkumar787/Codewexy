import React from "react";
import { Link } from "react-router-dom";
import Navbar from "./Navbar";

const Home = () => {
  return (
    <React.Fragment>
      <Navbar />
      <h4 className="text-success">Home Page</h4>
    </React.Fragment>
  );
};

export default Home;
