import React from "react";
import { Routes, Route } from "react-router-dom";
import Home from "./screens/Home";
import About from "./screens/About";
import HeadAndTail from "./screens/HeadAndTail";

const App = () => {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/headandtail" element={<HeadAndTail />} />
    </Routes>
  );
};

export default App;
